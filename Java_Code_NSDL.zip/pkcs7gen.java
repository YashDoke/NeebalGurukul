import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import java.util.Enumeration;
import java.util.List;
import java.util.ArrayList;
import org.bouncycastle.util.encoders.Base64;
import com.google.gson.Gson;
import java.security.cert.*;


public class pkcs7gen {
	public static void main(String args[]) throws Exception {
	if(args.length < 3)
        {
            System.out.println("java pkcs7gen oupt.jks pfxpswd  oupt.sig");
            System.exit(1);
        }
	
			/* args = new String[3];

			args[0]="output.jks";
			args[1]="emudhra";
			args[2]="output.sig"; */
			
			KeyStore keystore = KeyStore.getInstance("jks");
			InputStream input = new FileInputStream(args[0]);
			try {
				char[] password=args[1].toCharArray();
				keystore.load(input, password);
			} catch (IOException e) {
			} finally {

			}
			Enumeration e = keystore.aliases();
			String alias = "";

			if(e!=null)
			{
				while (e.hasMoreElements())
				{
					String  n = (String)e.nextElement();
					if (keystore.isKeyEntry(n))
					{
						alias = n;
					}
				}
			}
			PrivateKey privateKey=(PrivateKey) keystore.getKey(alias, args[1].toCharArray());
			X509Certificate myPubCert=(X509Certificate) keystore.getCertificate(alias);
			// changes here 
			CMSSignedDataGenerator sgen = new CMSSignedDataGenerator();
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider ());
			sgen.addSigner(privateKey, myPubCert,CMSSignedDataGenerator.DIGEST_SHA1);
			Certificate[] certChain =keystore.getCertificateChain(alias);
			ArrayList certList = new ArrayList();
			CertStore certs = null;
			for (int i=0; i < certChain.length; i++)
				certList.add(certChain[i]); 
			sgen.addCertificatesAndCRLs(CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC"));
			
			/*************************************/
			/*
			 * JSON Object created for creating a signature.
			 *  
			 */
			
			/*************************************/
			
			InputDataBean inputdataBean = new InputDataBean();
			ArrayList<InputDataBean> inputdataBeanList = new ArrayList();
			
			/*
			 * PAN 1 Mandatory
			 * */
			inputdataBean.setPan("CZCPA9469G");
			inputdataBean.setName("AALAM");
			inputdataBean.setFathername("");
			inputdataBean.setDob("15/08/1993");
			inputdataBeanList.add(inputdataBean);
			   
			/*
			 * PAN 2 Optional
			 * 
			 * Repeat for PAN 3 -- PAN 5
			 * */
			/*InputDataBean inputdataBean2 = new InputDataBean();
			inputdataBean2.setPan("AAATH3359M");
			inputdataBean2.setName("COMPANY PVT. LTD.");
			inputdataBean2.setFathername("");
			inputdataBean2.setDob("10/08/1966");
			inputdataBeanList.add(inputdataBean2);*/
			
			
		    Gson gson = new Gson();  
		    String inputdataBeanJson = gson.toJson(inputdataBeanList);
			
		   // System.out.print(inputdataBeanJson); 
		    byte[] dataToSign=inputdataBeanJson.getBytes();  
			
			CMSSignedData csd = sgen.generate(new CMSProcessableByteArray(dataToSign),true, "BC");
			byte[] signedData = csd.getEncoded();
			byte[] signedData64 = Base64.encode(signedData); 
			ByteArrayOutputStream byteArrayOutStr = new ByteArrayOutputStream();
			byteArrayOutStr.write(signedData64);
			 
			/*
			 * 
			 * Create Request Body of HIT
			 * 
			 * **/
			
			RequestBodyBean requestBody=new RequestBodyBean();
			requestBody.setInputData(inputdataBeanList);
			requestBody.setSignature(byteArrayOutStr.toString());
			
			System.out.print(gson.toJson(requestBody));
			try {
			FileWriter fWriter = new FileWriter(args[2]);
	        fWriter.write(gson.toJson(requestBody));
	            
	         fWriter.close();
	           
	            System.out.println( "File is created successfully with the content.");
			}catch(Exception e1)
			{
				e1.printStackTrace();
			}
		}

	
	}


/*
 * Input data Bean Class
 */

class InputDataBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String pan;
	private String name;
	private String fathername;
	private String dob;
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFathername() {
		return fathername;
	}
	public void setFathername(String fathername) {
		this.fathername = fathername;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
}

/*
 * Request Body Bean
 * 
 * */

 class RequestBodyBean implements Serializable  {


	 private static final long serialVersionUID = 1L;
		private ArrayList<InputDataBean> inputData;
		private String signature;
		
		public ArrayList<InputDataBean> getInputData() {
			return inputData;
		}
		public void setInputData(ArrayList<InputDataBean> inputData) {
			this.inputData = inputData;
		}
		public String getSignature() {
			return signature;
		}
		public void setSignature(String signature) {
			this.signature = signature;
		}
		@Override
		public String toString() {
			return "RequestBodyBean [inputData=" + inputData + ", signature=" + signature + "]";
		}

}
