import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;


import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Scanner;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import javax.net.ssl.X509TrustManager;




public class APIBasedAPIHit {
	
	public static class DummyTrustManager implements X509TrustManager {

		public DummyTrustManager() {
		}

		public boolean isClientTrusted(X509Certificate cert[]) {
			return true;
		}

		public boolean isServerTrusted(X509Certificate cert[]) {
			return true;
		}

		public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[0];
		}

		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

		}

		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

		}
	}
	public static class DummyHostnameVerifier implements HostnameVerifier {

		public boolean verify( String urlHostname, String certHostname ) {
			return true;
		}

		public boolean verify(String arg0, SSLSession arg1) {
			return true;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

		SSLContext sslcontext = null;
		try {
			sslcontext = SSLContext.getInstance("SSL");

			sslcontext.init(new KeyManager[0],
					new TrustManager[] { new DummyTrustManager() },
					new SecureRandom());
		} catch (NoSuchAlgorithmException e) {
			
			e.printStackTrace(System.err);
			
		} catch (KeyManagementException e) {
			
			e.printStackTrace(System.err);
			
		}
		

		SSLSocketFactory factory = sslcontext.getSocketFactory();
		String json = "";
		try {     
			File myObj = new File(args[0]);      
			Scanner myReader = new Scanner(myObj);     
			while (myReader.hasNextLine())
			{
				json = myReader.nextLine();        
				System.out.println(json);      
			}      
			myReader.close();    
			} catch (FileNotFoundException e) {      
				System.out.println("An error occurred.");      
				e.printStackTrace();
			}
		
		
		try {
		
		
		URL url;
		HttpsURLConnection connection;
		
		

		String ip="https://172.19.75.160/TIN/PanInquiryAPIBackEnd";
		url = new URL(ip);
		System.out.println("URL "+ip);
		connection = (HttpsURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Content-Type","application/json");
		connection.setRequestProperty("Content-Length", "" + Integer.toString(json.getBytes("utf-8").length));
		connection.setRequestProperty("Content-Language", "en-US");
		connection.setUseCaches (false);
		connection.setDoInput(true);
		connection.setDoOutput(true);
		connection.setSSLSocketFactory(factory);
		connection.setHostnameVerifier(new DummyHostnameVerifier());
		
		
		connection.setRequestProperty("User_ID", "V0024301"); 
		connection.setRequestProperty("Records_count", "2");
		connection.setRequestProperty("Request_time", "2024-01-08T11:35:50");
		connection.setRequestProperty("Transaction_ID", "V0024301:rssfd"); 
		connection.setRequestProperty("Version", "4");
		
		

		DataOutputStream wr = new DataOutputStream(connection.getOutputStream());         
		wr.writeBytes(json);        
		wr.flush();         
		wr.close();         

		int responseCode = connection.getResponseCode();         
		System.out.println("Response Code: " + responseCode);         

		BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));        
		String inputLine;        
		StringBuffer response = new StringBuffer();         
		while ((inputLine = in.readLine()) != null) 
		{             
			response.append(inputLine);         
		}         
		in.close();         
		System.out.println(response.toString());
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
